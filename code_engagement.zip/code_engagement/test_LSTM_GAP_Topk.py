import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import os
import shutil
import sys
import numpy as np
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import scipy.io as sio
# from torch.optim import lr_scheduler
import torchvision.models as models

sys.path.append('..');

from utils.database.Pixelmap import GAP_database_MIL;
from utils.model.model import LSTM_FC_GAP;

batch_size_num = 150;
epoch_num = 20000;
learning_rate = 0.001;
test_batch_size = 20;
log_file = '../log/test_LSTM_GAP_14.txt';
Is_use_shape = False;
Is_Finetune = False;
Is_First_time = True;
model_path = '../model/pretrain_model/selected/pretrain_butter.pth.tar';
finetune_model_path = '../model/pretrain/resnet18_color_10000.pth.tar';

# Data Loader
train_dataset = GAP_database_MIL(root_dir='../data/feature_self_def/train', Training = True);
train_loader = DataLoader(train_dataset, batch_size=batch_size_num,
                          shuffle=True, num_workers=2);

test_dataset = GAP_database_MIL(root_dir='../data/feature_self_def/validation', Training= False);
test_loader = DataLoader(test_dataset, batch_size=test_batch_size,
                         shuffle=True, num_workers=2);

net = LSTM_FC_GAP();
net.cuda();

print(net);

lossfunc = nn.L1Loss();

optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)  # optimize all cnn parameters

if not Is_First_time:
    temp = torch.load(model_path);
    optimizer.load_state_dict(temp['optimizer']);

def train(epoch):
    net.train();
    train_loss = 0;

    f = open(log_file, 'a+');
    f.write("epoch: {}\n".format(epoch));
    for batch_idx, (data, hr, idx) in enumerate(train_loader):
        # data = Variable(data.view(-1,feature_channel*feature_size));
        data = Variable(data);
        # target = Variable(target);
        hr = Variable(hr.view(-1,1));
        data, hr = data.cuda(), hr.cuda();

        output = net(data);

        # loss, loss1, loss2 = lossfunc(output, target, hr);
        loss = lossfunc(output, hr);

        train_loss += loss.data[0];

        optimizer.zero_grad()
        loss.backward()
        optimizer.step();

        f.write("train_loss: {}\n".format(loss.data[0]));
        if Is_use_shape:
            f.write('Train set: loss1: {:.8f}  loss2: {:.8f}'.format(loss1.data[0], loss2.data[0]));

    print("=====================");
    print("epoch: {}".format(epoch));
    print('Train loss: {:.8f}'.format(train_loss));

    f.write("=====================");
    f.write("epoch: {}".format(epoch));
    f.write('Train loss: {:.8f}'.format(train_loss));

def test(epoch):
    net.eval()
    test_loss = 0;

    gt = np.array([]);
    result = np.array([]);
    idx_all = np.array([]);
    for data, hr, idx in test_loader:
        data = Variable(data);
        hr = Variable(hr.view(-1,1));

        data, hr = data.cuda(), hr.cuda();
        output = net(data)

        loss = lossfunc(output, hr);

        if Is_use_shape:
            test_loss += loss.data[0];
            test_loss1 += loss1.data[0];
            test_loss2 += loss2.data[0];
        else:
            test_loss += loss.data[0];

        gt = np.append(gt, hr.data.cpu().numpy());
        result = np.append(result, output.data.cpu().numpy());
        idx_all = np.append(idx_all, idx.numpy());

    result_name = '../result/test_LSTM_GAP_14/result' + str(epoch) + '.mat';
    sio.savemat(result_name, dict(idx = idx_all, result=result, gt=gt));
    best_result = test_loss;

    f = open(log_file, 'a+');
    print('Test set: Average loss: {:.8f}'.format(test_loss));
    if Is_use_shape:
        print('Test set: loss1: {:.8f}  loss2: {:.8f}'.format(test_loss1, test_loss2));
    print("=====================");

    f.write('Test set: Average loss: {:.8f}\n'.format(test_loss));
    if Is_use_shape:
        f.write('Test set: loss1: {:.8f}  loss2: {:.8f}'.format(test_loss1, test_loss2));
    f.write("=====================");

    return best_result;

# scheduler = lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5);
def save_checkpoint(state, is_best, filename):
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, '../model/test_LSTM_GAP_14/model_best.pth.tar')


best_prec1 = 9999999;
f = open(log_file, 'a+');
f.write('***********************************\n');
if Is_First_time:
    begin_epoch = 1;
else:
    temp = torch.load(model_path);
    begin_epoch = temp['epoch'];

for epoch in range(begin_epoch, epoch_num + 1):
    # scheduler.step();
    train(epoch)
    prec1 = test(epoch);

    is_best = prec1 < best_prec1;
    best_prec1 = min(prec1, best_prec1)

    if epoch%100 == 0:
        save_name = '../model/test_LSTM_GAP_14/checkpoint' + str(epoch) + '.pth.tar';
        save_checkpoint({
            'epoch': epoch,
            'state_dict': net.state_dict(),
            'best_prec1': best_prec1,
            'optimizer': optimizer.state_dict(),
        }, is_best, save_name);

f.write('***********************************\n');
