import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import os
import shutil
import numpy as np
from torch.utils.data import Dataset, DataLoader
import scipy.io as sio
from PIL import Image
# from skimage import io, transform

class LBP_database(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;

        if self.train:
            feature_path = self.root_dir + '/feature_train.mat';
            label_path = self.root_dir + '/train_video_idx.mat';
        else:
            feature_path = self.root_dir + '/feature_test.mat';
            label_path = self.root_dir + '/test_video_idx.mat';

        self.feature = sio.loadmat(feature_path)['feature_all'];
        self.label = sio.loadmat(label_path)['original_label'];

        print(self.feature.shape[0])

    def __len__(self):
        print(self.feature.shape[0]);
        return self.feature.shape[0];

    def __getitem__(self, idx):

        feature_map = self.feature[idx, :];
        gt = self.label[idx, 0];

        feature_map = feature_map.astype('float32');
        gt = gt.astype('float32');

        return (feature_map, gt, idx);

class LBP_database_MIL(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        print(count);
        print('======================')
        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/feature.mat';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        # print(feature_path);
        # print('**************');

        feature = sio.loadmat(feature_path)['feature_all'];
        # print(feature)
        # print('-------------------------------------------------')
        # print(idx)
        label = sio.loadmat(label_path)['gt'];
        # print(label)
        # print('--------------------')

        feature_map = feature.astype('float32');
        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);

class LBP_database_MIL_14(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        print(count);
        print('======================')
        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/feature.mat';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        # print(feature_path);
        # print('**************');

        feature = sio.loadmat(feature_path)['feature_all'];
        # print(feature)
        # print('-------------------------------------------------')
        # print(idx)
        label = sio.loadmat(label_path)['gt'];
        # print(label)
        # print('--------------------')

        feature_map = feature.astype('float32');
        gt = label.astype('float32');

        gt = 4 - gt;

        return (feature_map, gt, idx);

class LBP_database_MIL_test(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;
        self.feature_num = 150;
        self.feature_length = 256*3;

    def __len__(self):
        count = 0;
        print(self.root_dir)
        for fn in os.listdir(self.root_dir):
            count = count+1;

        print(count);
        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        feature_map = np.zeros((self.feature_num, self.feature_length));
        for i in range(1, self.feature_num+1):
            feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
            feature_temp = sio.loadmat(feature_temp_path)['Histogram'];
            feature_map[i-1,:] = feature_temp;

        # print(feature_path);
        # print('**************');

        label = sio.loadmat(label_path)['gt'];

        feature_map = feature_map.astype('float32');
        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);

class GAP_database_MIL(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;
        self.feature_num = 150;
        self.feature_length = 117;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        count = count-1;
        print(count);
        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        feature_map = np.zeros((self.feature_num, self.feature_length));
        for i in range(1, self.feature_num+1):
            feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
            feature_temp = sio.loadmat(feature_temp_path)['feature_all'];
            feature_map[i-1,:] = feature_temp;

        # print(feature_path);
        # print('**************');

        label = sio.loadmat(label_path)['gt'];

        feature_map = feature_map.astype('float32');
        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);

class GAP_database_MIL_14(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;
        self.feature_num = 150;
        self.feature_length = 117;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        count = count-1;
        print(count);
        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        feature_map = np.zeros((self.feature_num, self.feature_length));
        for i in range(1, self.feature_num+1):
            feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
            feature_temp = sio.loadmat(feature_temp_path)['feature_all'];
            feature_map[i-1,:] = feature_temp;

        # print(feature_path);
        # print('**************');

        label = sio.loadmat(label_path)['gt'];

        feature_map = feature_map.astype('float32');
        gt = label.astype('float32');

        gt = 4 - gt;

        return (feature_map, gt, idx);

class Fre_database_mat(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/fre.mat';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        # print(feature_path);
        # print('**************');
        feature = sio.loadmat(feature_path)['fre_data'];
        label = sio.loadmat(label_path)['gt'];

        feature_map = feature.astype('float32');
        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);


class Fre_database_img(Dataset):
    def __init__(self, root_dir, Training = True, transform = None):
        self.train = Training
        self.root_dir = root_dir;
        self.transform = transform;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/fre_img.png';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        feature_map = Image.open(feature_path).convert('RGB');

        box = (0, 0, 512, 31)
        feature_map = feature_map.crop(box)

        # print(feature_map);
        if self.transform:
            feature_map = self.transform(feature_map);

        label = sio.loadmat(label_path)['gt'];

        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);

class Fre_database_img_lmk(Dataset):
    def __init__(self, root_dir, Training = True, transform = None):
        self.train = Training
        self.root_dir = root_dir;
        self.transform = transform;

    def __len__(self):
        count = 0;
        for fn in os.listdir(self.root_dir):
            count = count+1;

        return count;

    def __getitem__(self, idx):

        feature_path = self.root_dir + '/'+ str(idx+1) + '/fre_img.png';
        label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

        feature_map = Image.open(feature_path).convert('RGB');

        box = (0, 32, 512, 371)
        feature_map = feature_map.crop(box)

        # print(feature_map);
        if self.transform:
            feature_map = self.transform(feature_map);

        label = sio.loadmat(label_path)['gt'];

        gt = label.astype('float32');

        # gt = 4 - gt;

        return (feature_map, gt, idx);


class GAP_database_rank(Dataset):
    def __init__(self, root_dir, Training=True):
        self.train = Training
        self.root_dir = root_dir;
        self.feature_num = 150;
        self.feature_length = 117;

        if self.train:
            path = self.root_dir + '/rank_data.mat';
            print(path);
            self.rank_data = sio.loadmat(path)['rank_data'];

    def __len__(self):

        if self.train:
            count = self.rank_data.shape[0];
        else:
            count = 0;
            for fn in os.listdir(self.root_dir):
                count = count+1;

        print(count);
        return count;

    def __getitem__(self, idx):

        if self.train:
            idx1 = self.rank_data[idx, 0];
            idx2 = self.rank_data[idx, 1];

            feature_path = self.root_dir + '/' + str(idx1) + '/';
            label_path = self.root_dir + '/' + str(idx1) + '/label.mat';

            feature_map1 = np.zeros((self.feature_num, self.feature_length));
            for i in range(1, self.feature_num + 1):
                feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
                feature_temp = sio.loadmat(feature_temp_path)['feature_all'];
                feature_map1[i - 1, :] = feature_temp;

            label1 = sio.loadmat(label_path)['gt'];

            feature_map1 = feature_map1.astype('float32');
            gt1 = label1.astype('float32');

########################################################################
            feature_path = self.root_dir + '/' + str(idx2) + '/';
            label_path = self.root_dir + '/' + str(idx2) + '/label.mat';

            feature_map2 = np.zeros((self.feature_num, self.feature_length));
            for i in range(1, self.feature_num + 1):
                feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
                feature_temp = sio.loadmat(feature_temp_path)['feature_all'];
                feature_map2[i - 1, :] = feature_temp;

            label2 = sio.loadmat(label_path)['gt'];

            feature_map2 = feature_map2.astype('float32');
            gt2 = label2.astype('float32');

#######################################################################

            rank_l = self.rank_data[idx, 2];
            rank_l = rank_l.astype('float32');

            output = (feature_map1, feature_map2, gt1, gt2, rank_l, idx);
        else:
            feature_path = self.root_dir + '/'+ str(idx+1) + '/';
            label_path = self.root_dir + '/' + str(idx+1) + '/label.mat';

            feature_map = np.zeros((self.feature_num, self.feature_length));
            for i in range(1, self.feature_num+1):
                feature_temp_path = feature_path + 'feature' + str(i) + '.mat';
                feature_temp = sio.loadmat(feature_temp_path)['feature_all'];
                feature_map[i-1,:] = feature_temp;

            # print(feature_path);
            # print('**************');

            label = sio.loadmat(label_path)['gt'];

            feature_map = feature_map.astype('float32');
            gt = label.astype('float32');
            output = (feature_map, gt, idx);
        # gt = 4 - gt;

        return output;