import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import os
import shutil
import numpy as np
import scipy.io as sio

class FC_LBP(nn.Module):
    def __init__(self):
        super(FC, self).__init__()

        self.feature_length = 256*3;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        # self.fc4 = nn.Linear(512, 1);
        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):
        x = F.relu(self.fc1(x));
        x = self.dropout(x);
        x = F.relu(self.fc2(x));
        x = self.dropout(x);
        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        return x

class FC_GAP(nn.Module):
    def __init__(self):
        super(FC, self).__init__()

        self.feature_length = 117;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        # self.fc4 = nn.Linear(512, 1);
        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):
        x = F.relu(self.fc1(x));
        x = self.dropout(x);
        x = F.relu(self.fc2(x));
        x = self.dropout(x);
        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        return x



class DMIL_FC(nn.Module):
    def __init__(self):
        super(DMIL_FC, self).__init__()

        self.feature_length = 256*3;
        self.instance_num = 150;
        self.k = 10;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        x = x.view(-1, self.feature_length);

        x = F.relu(self.fc1(x));
        x = self.dropout(x);
        x = F.relu(self.fc2(x));
        x = self.dropout(x);
        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);
        # print(x);
        # print('///////////////////////////');

        x = torch.mean(x, dim = 1);

        return x

class DMIL_FC_GAP(nn.Module):
    def __init__(self):
        super(DMIL_FC_GAP, self).__init__()

        self.feature_length = 117;
        self.instance_num = 150;
        self.k = 10;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        x = x.view(-1, self.feature_length);

        x = F.relu(self.fc1(x));
        x = self.dropout(x);
        x = F.relu(self.fc2(x));
        x = self.dropout(x);
        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);
        # print(x);
        # print('///////////////////////////');

        x = torch.mean(x, dim = 1);

        return x

class LSTM_FC_GAP(nn.Module):
    def __init__(self):
        super(LSTM_FC_GAP, self).__init__()

        self.feature_length = 117;
        self.instance_num = 150;
        self.k = 150;

        self.GRU = nn.GRU(self.feature_length,512);
        # self.fc1 = nn.Linear(self.feature_length, 1024);
        # self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        B = x.size(0);
        T = x.size(1);
        N = x.size(2);

        x = x.view(B,T,-1);
        x = x.permute(1, 0, 2);  # T, B, N

        # print(x);

        x, _ = self.GRU(x);

        x = x.permute(1, 0, 2).contiguous();  # B, T, N

        # print(x);

        x = x.view(B*T, -1);

        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);

        x = torch.mean(x, dim = 1);

        return x

class LSTM_FC_LBP(nn.Module):
    def __init__(self):
        super(LSTM_FC_LBP, self).__init__()

        self.feature_length = 768;
        self.instance_num = 150;
        self.k = 150;

        self.GRU = nn.GRU(self.feature_length,512);
        # self.fc1 = nn.Linear(self.feature_length, 1024);
        # self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        B = x.size(0);
        T = x.size(1);
        N = x.size(2);

        x = x.view(B,T,-1);
        x = x.permute(1, 0, 2);  # T, B, N

        # print(x);

        x, _ = self.GRU(x);

        x = x.permute(1, 0, 2).contiguous();  # B, T, N

        # print(x);

        x = x.view(B*T, -1);

        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);

        x = torch.mean(x, dim = 1);

        return x


class DMIL_FC_mean(nn.Module):
    def __init__(self):
        super(DMIL_FC_mean, self).__init__()

        self.feature_length = 256*3;
        self.instance_num = 150;
        self.k = 10;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        x = x.view(-1, self.feature_length);

        x = F.relu(self.fc1(x));
        x = self.dropout(x);
        x = F.relu(self.fc2(x));
        x = self.dropout(x);
        x = F.relu(self.fc3(x));
        x = self.dropout(x);
        x = self.fc4(x);

        x = x.view(-1, self.instance_num);

        # x,_ = torch.topk(x, k = self.k, dim = 1);
        # print(x);
        # print('///////////////////////////');

        x = torch.mean(x, dim = 1);

        return x


class DMIL_FC_swish(nn.Module):
    def __init__(self):
        super(DMIL_FC_swish, self).__init__()

        self.feature_length = 256*3;
        self.instance_num = 150;
        self.k = 10;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        x = x.view(-1, self.feature_length);

        x = self.fc1(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc2(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc3(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc4(x);
        x = x * torch.sigmoid(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);
        # print(x);
        # print('///////////////////////////');

        x = torch.mean(x, dim = 1);

        return x


class DMIL_FC_class(nn.Module):
    def __init__(self):
        super(DMIL_FC_class, self).__init__()

        self.feature_length = 256*3;
        self.instance_num = 150;
        self.k = 10;

        self.fc1 = nn.Linear(self.feature_length, 1024);
        self.fc2 = nn.Linear(1024, 512);
        self.fc3 = nn.Linear(512, 128);
        self.fc4 = nn.Linear(128, 4);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        x = x.view(-1, self.feature_length);

        x = self.fc1(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc2(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc3(x);
        x = x * torch.sigmoid(x);
        x = self.dropout(x);

        x = self.fc4(x);
        x = x * torch.sigmoid(x);

        x = x.view(-1, self.instance_num);

        x,_ = torch.topk(x, k = self.k, dim = 1);
        # print(x);
        # print('///////////////////////////');

        x = torch.mean(x, dim = 1);

        return x



class ConFFT(nn.Module):
    def __init__(self):
        super(ConFFT, self).__init__()

        self.channel = 3;

        self.conv1 = nn.Conv2d(self.channel, 64, kernel_size = (1,3));
        self.conv2 = nn.Conv2d(64, 128, kernel_size = (1,3));

        self.conv3 = nn.Conv2d(128, 128, kernel_size = (31,1));
        self.conv4 = nn.Conv2d(128, 128, kernel_size = (1,7));

        self.pool = nn.MaxPool2d(kernel_size = (1,9))

        self.fc = nn.Linear(128*5, 1);

        self.dropout = nn.Dropout(p=0.5);

    def forward(self, x):

        # print(x);
        # print('**************************');
        x = F.relu(self.conv1(x));
        x = F.relu(self.conv2(x));

        x = self.pool(x);

        x = F.relu(self.conv3(x));
        x = F.relu(self.conv4(x));

        x = self.pool(x);

        # print(x);
        # print('///////////////////////////');
        x = x.view(-1, 128*5);

        x = self.fc(x);

        return x
